package com.example.mybabymonitor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    CardView prnButton, bbyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prnButton = (CardView) findViewById(R.id.parentBtn);
        bbyButton = (CardView) findViewById(R.id.babyBtn);

        prnButton.setOnClickListener(this);
        bbyButton.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.parentBtn :
                Intent parent = new Intent(MainActivity.this, ParentActivity.class);
                this.startActivity(parent);

                break;

            case R.id.babyBtn :
                Intent baby = new Intent(MainActivity.this, BabyActivity.class);
                this.startActivity(baby);

                break;
        }
    }
}
